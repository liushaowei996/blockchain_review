# Anonymous Submission Checklist

## Scope and article type

- [x] Journal class is `\documentclass[blockchains,review,submit,moreauthors]{Definitions/mdpi}`.
- [x] Manuscript is framed as a narrative Review and makes no exhaustive-search claim.
- [x] No new empirical dataset, experiment, performance result, or protocol proof is reported.
- [x] UAV--USV--UUV systems are the core; satellite, shore, cloud, and edge nodes are supporting infrastructure.
- [x] Civil and public defense-support contexts exclude weapon effects, targeting procedures, and sensitive tactics.

## Original synthesis

- [x] OAL is identified as the authors' proposed analytical framework.
- [x] CTG is a conceptual evidence-reasoning loop, not a calibrated algorithm.
- [x] CDUTP is identified as a future author proposal, not a current standard.
- [x] Blockchain claims distinguish physical truth, provenance, ledger consistency, privacy, endpoint security, governance, partition tolerance, and hard real-time control.
- [x] Threat analysis distinguishes malicious action, benign degradation, and insufficient evidence.

## Evidence and references

- [x] 140 unique references are cited; all citekeys resolve.
- [x] DOI-bearing entries were resolved against Crossref or an authoritative publisher record.
- [x] Standards and specifications link to official NIST, RFC Editor, W3C, 3GPP, or Hyperledger sources.
- [x] The evidence matrix distinguishes metadata verification from pending full-text analytical coding.
- [ ] Authors have lawfully obtained and inspected all high-priority paywalled full texts.
- [ ] Pending method, assumption, maturity, and limitation fields have been completed or removed.
- [ ] All strong gap or prevalence statements have been rechecked against the completed matrix.
- [ ] Literature and specifications have been updated within 14 days of submission.

## Front and back matter

- [x] Abstract is one paragraph and 186 words.
- [x] Eight keywords are supplied.
- [x] Anonymous author, affiliation, correspondence, CRediT, and funding placeholders contain no real identity.
- [x] No-new-data, conflict-of-interest, ethics, consent, and GenAI statements are present.
- [ ] Real author metadata, affiliations, ORCID identifiers, CRediT roles, funding, and correspondence are ready for the journal system.
- [ ] Special Issue status, deadline, invitation/editorial pre-assessment, and any APC waiver have been reconfirmed.

## Files and technical QA

- [x] `latexmk`/`pdflatex` build completes without errors.
- [x] No undefined citation, undefined cross-reference, duplicate label, missing figure, or overfull box remains.
- [x] Seven figures are editable TikZ vector sources; eight tables are editable LaTeX.
- [x] All 34 PDF pages were rendered and visually checked for clipping, figure legibility, table width, references, and anonymity.
- [x] The anonymous PDF and source package contain no `turn...` citation placeholders.
- [ ] Final files have been checked in the journal submission preview after upload.
